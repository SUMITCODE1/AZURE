﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Cloud_Azure_Assignment8.Startup))]
namespace Cloud_Azure_Assignment8
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}

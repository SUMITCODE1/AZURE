﻿using System.Web;
using System.Web.Mvc;

namespace Cloud_Azure_Assignment8
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
